# ClearDay: install guide (beginner)

IMPORTANT: this project was written and its logic was tested, but it has NOT been compiled
into an APK yet (the environment it was written in cannot reach Google's download servers).
The first time you open it, Android Studio will build it. If it shows a red error, send me
the exact error text and I will fix it.

## EASIEST: let GitHub build the APK for you (no Android Studio)
1. Create a free account at github.com, then New repository > name it ClearDay > choose PRIVATE > Create.
2. On your computer, unzip ClearDay.zip. On the repository page click "uploading an existing file",
   drag in EVERYTHING inside the ClearDay folder (including the hidden .github folder), click Commit.
3. Open the "Actions" tab. A build called "Build ClearDay APK" starts automatically (about 5-10 minutes).
   A green tick means it compiled and all tests passed. A red cross means an error: open it and send me the error text.
4. Click the finished run, scroll to "Artifacts", download ClearDay-APK, unzip it to get app-debug.apk.
5. Send app-debug.apk to your Pixel (email, Drive or USB), tap it, and allow "install unknown apps" when asked.

## Alternative: Android Studio (below)

## EASIEST: let GitHub build it for you (no Android Studio)
1. Create a free account at github.com and click New repository (name: ClearDay, Private).
2. On your computer, unzip ClearDay.zip. In the new repository click "uploading an existing file"
   and drag in EVERYTHING inside the ClearDay folder (include the hidden .github folder), then Commit.
3. Open the Actions tab > "Build ClearDay APK" > Run workflow. Wait ~5-10 minutes.
4. Open the finished run, download "ClearDay-apk" (a zip containing app-debug.apk).
5. Copy app-debug.apk to your Pixel, tap it, allow "install unknown apps" when asked.
If the run shows a red X, open it and send me the first error line.

## Alternative: Android Studio
## What you need (all free)
- A computer (Windows, Mac or Linux) with internet for the first build only
- Android Studio: https://developer.android.com/studio (install with default options)
- A USB cable for your Pixel 8 Pro

## Steps
1. Unzip ClearDay.zip somewhere easy (e.g. Documents).
2. Open Android Studio > "Open" > pick the folder named ClearDay (the one containing settings.gradle.kts).
3. Wait. The bottom bar shows "Gradle sync" and downloads things (5-15 minutes the first time).
   If asked to "Trust project", click Trust. If asked to install an SDK or update a plugin, accept.
4. On the Pixel: Settings > About phone > tap "Build number" 7 times > back > System >
   Developer options > turn on "USB debugging".
5. Plug the phone into the computer, tap "Allow" on the phone's USB-debugging prompt.
6. At the top of Android Studio choose "Pixel 8 Pro" in the device box and press the green Run button.
   ClearDay installs and opens on your phone.

## Optional: get an APK file
Build > Build Bundle(s) / APK(s) > Build APK(s). Click "locate" when it finishes.
app-debug.apk can be copied to the phone and tapped to install (allow "install unknown apps" for your file manager).

## Run the tests
In Android Studio: right-click app/src/test > Run 'Tests in ...'.

## Streak rules
- Only days you approve count. Nothing is approved automatically. Future days never count.
- Current streak = consecutive approved days ending today. If today isn't approved yet,
  the streak is counted back from yesterday (your day isn't over). If yesterday was missed, it is 0.
- Longest streak and total days are calculated within the current challenge. Missing a day never deletes history.
- Starting a new challenge keeps old approved days in the calendar.

## Notifications
Reminders (default 9:00 PM) use inexact alarms, so Android may delay them a few minutes
(Battery Saver, Doze). No special alarm permission is needed. They are rescheduled after reboot,
app update, clock change and time-zone change.

## Privacy
No internet permission, no account, no analytics, no ads. Data is stored in the app's private
storage, and Android backup is turned off. Export saves a small JSON file where you choose.
