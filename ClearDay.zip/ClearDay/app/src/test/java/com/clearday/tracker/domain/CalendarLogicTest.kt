package com.clearday.tracker.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth

class CalendarLogicTest {
    private val today = LocalDate.of(2026, 3, 10)
    private val start = LocalDate.of(2026, 3, 1)
    private val approved = setOf(LocalDate.of(2026, 3, 2), LocalDate.of(2026, 3, 10))

    @Test fun statuses() {
        assertEquals(DayStatus.APPROVED, CalendarLogic.statusOf(LocalDate.of(2026, 3, 2), today, approved, start))
        assertEquals(DayStatus.APPROVED, CalendarLogic.statusOf(today, today, approved, start))
        assertEquals(DayStatus.MISSED, CalendarLogic.statusOf(LocalDate.of(2026, 3, 5), today, approved, start))
        assertEquals(DayStatus.PENDING_TODAY, CalendarLogic.statusOf(today, today, emptySet(), start))
        assertEquals(DayStatus.FUTURE, CalendarLogic.statusOf(LocalDate.of(2026, 3, 11), today, approved, start))
        assertEquals(DayStatus.BEFORE_CHALLENGE, CalendarLogic.statusOf(LocalDate.of(2026, 2, 20), today, approved, start))
    }

    @Test fun futureDayIsNeverApproved_evenIfSomehowStored() {
        val tomorrow = today.plusDays(1)
        assertEquals(DayStatus.FUTURE, CalendarLogic.statusOf(tomorrow, today, setOf(tomorrow), start))
    }

    @Test fun editRules() {
        assertTrue(CalendarLogic.canEdit(today, today, start))
        assertTrue(CalendarLogic.canEdit(start, today, start))
        assertFalse(CalendarLogic.canEdit(today.plusDays(1), today, start))
        assertFalse(CalendarLogic.canEdit(start.minusDays(1), today, start))
    }

    @Test fun gridSizeIsAlwaysWholeWeeks_andContainsEveryDayOnce() {
        for (m in listOf(YearMonth.of(2026, 2), YearMonth.of(2028, 2), YearMonth.of(2026, 3), YearMonth.of(2026, 12), YearMonth.of(2027, 1))) {
            for (dow in listOf(DayOfWeek.MONDAY, DayOfWeek.SUNDAY, DayOfWeek.SATURDAY)) {
                val g = CalendarLogic.monthGrid(m, dow)
                assertEquals(0, g.size % 7)
                assertEquals(m.lengthOfMonth(), g.filterNotNull().size)
                assertEquals(m.atDay(1), g.filterNotNull().first())
                assertEquals(m.atEndOfMonth(), g.filterNotNull().last())
            }
        }
    }

    @Test fun firstDayAlignsToTheRightColumn() {
        // 1 March 2026 is a Sunday.
        val mon = CalendarLogic.monthGrid(YearMonth.of(2026, 3), DayOfWeek.MONDAY)
        assertEquals(6, mon.indexOfFirst { it != null })
        val sun = CalendarLogic.monthGrid(YearMonth.of(2026, 3), DayOfWeek.SUNDAY)
        assertEquals(0, sun.indexOfFirst { it != null })
        assertNull(mon[0])
    }

    @Test fun leapYearFebruary_has29Days_andNonLeap28() {
        assertEquals(29, CalendarLogic.monthGrid(YearMonth.of(2028, 2), DayOfWeek.MONDAY).filterNotNull().size)
        assertEquals(28, CalendarLogic.monthGrid(YearMonth.of(2027, 2), DayOfWeek.MONDAY).filterNotNull().size)
    }

    @Test fun monthNavigationAcrossYearBoundary() {
        assertEquals(YearMonth.of(2027, 1), YearMonth.of(2026, 12).plusMonths(1))
        assertEquals(YearMonth.of(2025, 12), YearMonth.of(2026, 1).plusMonths(-1))
    }
}
