package com.clearday.tracker.domain

import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate

class StreakCalculatorTest {
    private val today = LocalDate.of(2026, 3, 10)
    private val start = LocalDate.of(2026, 3, 1)

    private fun days(vararg d: Int) = d.map { LocalDate.of(2026, 3, it) }.toSet()

    @Test fun noApprovals_everythingIsZero() {
        assertEquals(0, StreakCalculator.currentStreak(emptySet(), today, start))
        assertEquals(0, StreakCalculator.longestStreak(emptySet(), today, start))
        assertEquals(0, StreakCalculator.totalApproved(emptySet(), today, start))
    }

    @Test fun todayApproved_countsTowardCurrentStreak() {
        assertEquals(1, StreakCalculator.currentStreak(days(10), today, start))
        assertEquals(4, StreakCalculator.currentStreak(days(7, 8, 9, 10), today, start))
    }

    @Test fun todayNotYetApproved_streakStaysAliveFromYesterday() {
        assertEquals(3, StreakCalculator.currentStreak(days(7, 8, 9), today, start))
    }

    @Test fun missedYesterday_currentStreakIsZero() {
        assertEquals(0, StreakCalculator.currentStreak(days(5, 6, 7, 8), today, start))
    }

    @Test fun missedYesterdayButApprovedToday_streakRestartsAtOne() {
        assertEquals(1, StreakCalculator.currentStreak(days(5, 6, 7, 8, 10), today, start))
    }

    @Test fun gapInTheMiddle_endsTheRun() {
        assertEquals(3, StreakCalculator.currentStreak(days(1, 2, 3, 8, 9, 10), today, start))
    }

    @Test fun longestStreak_findsBestRun_notJustCurrent() {
        val approved = days(1, 2, 3, 4, 5, 8, 9)
        assertEquals(5, StreakCalculator.longestStreak(approved, today, start))
        assertEquals(2, StreakCalculator.currentStreak(approved, today, start))
    }

    @Test fun missingADay_doesNotRemoveHistory() {
        val approved = days(1, 2, 3, 4)
        assertEquals(4, StreakCalculator.totalApproved(approved, today, start))
        assertEquals(4, StreakCalculator.longestStreak(approved, today, start))
        assertEquals(0, StreakCalculator.currentStreak(approved, today, start))
    }

    @Test fun futureDatesNeverCount() {
        val approved = days(9, 10, 11, 12, 13)
        assertEquals(2, StreakCalculator.totalApproved(approved, today, start))
        assertEquals(2, StreakCalculator.currentStreak(approved, today, start))
        assertEquals(2, StreakCalculator.longestStreak(approved, today, start))
    }

    @Test fun datesBeforeChallengeStart_areIgnoredButNotDeleted() {
        val approved = setOf(LocalDate.of(2026, 2, 27), LocalDate.of(2026, 2, 28), LocalDate.of(2026, 3, 1))
        assertEquals(1, StreakCalculator.totalApproved(approved, LocalDate.of(2026, 3, 1), start))
        assertEquals(1, StreakCalculator.longestStreak(approved, LocalDate.of(2026, 3, 1), start))
        assertEquals(3, approved.size)
    }

    @Test fun streakCrossesMonthBoundary() {
        val approved = setOf(LocalDate.of(2026, 2, 27), LocalDate.of(2026, 2, 28), LocalDate.of(2026, 3, 1), LocalDate.of(2026, 3, 2))
        val s = LocalDate.of(2026, 2, 20)
        assertEquals(4, StreakCalculator.currentStreak(approved, LocalDate.of(2026, 3, 2), s))
    }

    @Test fun streakCrossesYearBoundary() {
        val approved = setOf(LocalDate.of(2025, 12, 30), LocalDate.of(2025, 12, 31), LocalDate.of(2026, 1, 1))
        val s = LocalDate.of(2025, 12, 1)
        assertEquals(3, StreakCalculator.currentStreak(approved, LocalDate.of(2026, 1, 1), s))
        assertEquals(3, StreakCalculator.longestStreak(approved, LocalDate.of(2026, 1, 1), s))
    }

    @Test fun leapDay_isConsecutiveBetweenFeb28AndMar1InLeapYear() {
        val approved = setOf(LocalDate.of(2028, 2, 28), LocalDate.of(2028, 2, 29), LocalDate.of(2028, 3, 1))
        assertEquals(3, StreakCalculator.currentStreak(approved, LocalDate.of(2028, 3, 1), LocalDate.of(2028, 2, 1)))
    }

    @Test fun noLeapDay_inNonLeapYear_feb28ThenMar1AreConsecutive() {
        val approved = setOf(LocalDate.of(2027, 2, 28), LocalDate.of(2027, 3, 1))
        assertEquals(2, StreakCalculator.currentStreak(approved, LocalDate.of(2027, 3, 1), LocalDate.of(2027, 2, 1)))
    }

    @Test fun daylightSavingChangeDays_areStillConsecutiveCalendarDays() {
        // US spring-forward 2026-03-08 has only 23 hours; calendar dates must still be consecutive.
        val approved = setOf(LocalDate.of(2026, 3, 7), LocalDate.of(2026, 3, 8), LocalDate.of(2026, 3, 9))
        assertEquals(3, StreakCalculator.currentStreak(approved, LocalDate.of(2026, 3, 9), LocalDate.of(2026, 3, 1)))
        // EU fall-back 2026-10-25 has 25 hours.
        val fall = setOf(LocalDate.of(2026, 10, 24), LocalDate.of(2026, 10, 25), LocalDate.of(2026, 10, 26))
        assertEquals(3, StreakCalculator.currentStreak(fall, LocalDate.of(2026, 10, 26), LocalDate.of(2026, 10, 1)))
    }

    @Test fun midnightRollover_streakKeepsWhenNewDayStartsUnapproved() {
        val approved = days(8, 9, 10)
        assertEquals(3, StreakCalculator.currentStreak(approved, LocalDate.of(2026, 3, 10), start))
        // After midnight "today" becomes the 11th: not approved yet, yesterday was -> still 3.
        assertEquals(3, StreakCalculator.currentStreak(approved, LocalDate.of(2026, 3, 11), start))
        // A full day later with no approval -> streak ended.
        assertEquals(0, StreakCalculator.currentStreak(approved, LocalDate.of(2026, 3, 12), start))
    }

    @Test fun duplicateApprovals_cannotExistBecauseDatesAreASet() {
        val approved = setOf(LocalDate.of(2026, 3, 10), LocalDate.of(2026, 3, 10))
        assertEquals(1, approved.size)
        assertEquals(1, StreakCalculator.totalApproved(approved, today, start))
    }
}
