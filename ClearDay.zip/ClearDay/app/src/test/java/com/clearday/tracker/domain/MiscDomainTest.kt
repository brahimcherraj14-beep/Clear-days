package com.clearday.tracker.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

class MiscDomainTest {

    @Test fun achievements_unlockAtMilestones() {
        fun unlocked(n: Int) = Achievements.evaluate(n).filter { it.unlocked }.map { it.days }
        assertEquals(emptyList<Int>(), unlocked(0))
        assertEquals(emptyList<Int>(), unlocked(2))
        assertEquals(listOf(3), unlocked(3))
        assertEquals(listOf(3, 7), unlocked(10))
        assertEquals(listOf(3, 7, 14), unlocked(14))
        assertEquals(listOf(3, 7, 14, 30), unlocked(45))
        assertEquals(listOf(3, 7, 14, 30), Achievements.MILESTONES)
    }

    @Test fun dashboard_combinesEverything() {
        val start = LocalDate.of(2026, 3, 1)
        val today = LocalDate.of(2026, 3, 8)
        val approved = (1..8).map { LocalDate.of(2026, 3, it) }.toSet() - LocalDate.of(2026, 3, 4)
        val s = DashboardCalculator.compute(approved, today, start)
        assertEquals(4, s.currentStreak)
        assertEquals(4, s.longestStreak)
        assertEquals(7, s.totalApproved)
        assertTrue(s.todayApproved)
        assertEquals(8, s.progress.dayNumber)
        assertEquals(listOf(3), s.achievements.filter { it.unlocked }.map { it.days })
    }

    @Test fun dashboard_todayNotApproved() {
        val s = DashboardCalculator.compute(emptySet(), LocalDate.of(2026, 3, 8), LocalDate.of(2026, 3, 1))
        assertFalse(s.todayApproved)
        assertEquals(0, s.currentStreak)
    }

    @Test fun reminder_beforeTimeToday_firesToday() {
        val zone = ZoneId.of("Europe/Paris")
        val now = ZonedDateTime.of(2026, 3, 10, 20, 0, 0, 0, zone)
        val next = nextReminderTime(now, 21, 0)
        assertEquals(LocalDate.of(2026, 3, 10), next.toLocalDate())
        assertEquals(21, next.hour)
    }

    @Test fun reminder_afterTimeToday_firesTomorrow() {
        val zone = ZoneId.of("Europe/Paris")
        val now = ZonedDateTime.of(2026, 3, 10, 21, 0, 0, 0, zone)
        assertEquals(LocalDate.of(2026, 3, 11), nextReminderTime(now, 21, 0).toLocalDate())
        val later = ZonedDateTime.of(2026, 3, 10, 23, 59, 0, 0, zone)
        assertEquals(LocalDate.of(2026, 3, 11), nextReminderTime(later, 21, 0).toLocalDate())
    }

    @Test fun reminder_staysAt9pmLocalTime_acrossDaylightSaving() {
        val zone = ZoneId.of("America/New_York") // spring forward on 2026-03-08
        val now = ZonedDateTime.of(2026, 3, 7, 22, 0, 0, 0, zone)
        val next = nextReminderTime(now, 21, 0)
        assertEquals(LocalDate.of(2026, 3, 8), next.toLocalDate())
        assertEquals(21, next.hour)
        assertEquals(0, next.minute)
    }

    @Test fun reminder_timeInsideDstGap_isStillInTheFuture() {
        val zone = ZoneId.of("America/New_York")
        val now = ZonedDateTime.of(2026, 3, 8, 0, 30, 0, 0, zone)
        val next = nextReminderTime(now, 2, 30) // 02:30 does not exist that day
        assertTrue(next.isAfter(now))
    }

    @Test fun reminder_followsTimeZoneChanges() {
        val ny = ZonedDateTime.of(2026, 3, 10, 20, 0, 0, 0, ZoneId.of("America/New_York"))
        val sameInstantInTokyo = ny.withZoneSameInstant(ZoneId.of("Asia/Tokyo"))
        // Tokyo local time is 09:00 on the 11th, so 21:00 Tokyo is later the same Tokyo day.
        val next = nextReminderTime(sameInstantInTokyo, 21, 0)
        assertEquals(11, next.dayOfMonth)
        assertEquals(21, next.hour)
    }

    @Test fun export_isValidLookingAndSorted() {
        val json = ExportFormatter.toJson(
            LocalDate.of(2026, 3, 10), LocalDate.of(2026, 3, 1),
            setOf(LocalDate.of(2026, 3, 5), LocalDate.of(2026, 3, 2))
        )
        assertTrue(json.contains("\"exportedOn\": \"2026-03-10\""))
        assertTrue(json.indexOf("2026-03-02") < json.indexOf("2026-03-05"))
        assertEquals(json.count { it == '{' }, json.count { it == '}' })
    }

    @Test fun export_emptyHistory() {
        val json = ExportFormatter.toJson(LocalDate.of(2026, 3, 10), LocalDate.of(2026, 3, 1), emptySet())
        assertTrue(json.contains("\"approvedDates\": []"))
    }
}
