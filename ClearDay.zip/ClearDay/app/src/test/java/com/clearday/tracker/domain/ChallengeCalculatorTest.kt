package com.clearday.tracker.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class ChallengeCalculatorTest {
    private val start = LocalDate.of(2026, 3, 1)

    @Test fun windowHasExactly30ConsecutiveDays() {
        val w = ChallengeCalculator.windowDays(start)
        assertEquals(30, w.size)
        assertEquals(start, w.first())
        assertEquals(LocalDate.of(2026, 3, 30), w.last())
    }

    @Test fun firstDay_isDayOne() {
        val p = ChallengeCalculator.progress(emptySet(), start, start)
        assertEquals(1, p.dayNumber)
        assertEquals(0, p.approvedInWindow)
        assertEquals(0, p.percentOfChallenge)
    }

    @Test fun dayNumberIsCappedAt30_andChallengeFinishes() {
        val p = ChallengeCalculator.progress(emptySet(), LocalDate.of(2026, 6, 1), start)
        assertEquals(30, p.dayNumber)
        assertTrue(p.isFinished)
    }

    @Test fun startInTheFuture_dayNumberIsZero() {
        val p = ChallengeCalculator.progress(emptySet(), LocalDate.of(2026, 2, 20), start)
        assertEquals(0, p.dayNumber)
        assertFalse(p.isFinished)
    }

    @Test fun percentages() {
        fun pct(n: Int): Int {
            val approved = (0 until n).map { start.plusDays(it.toLong()) }.toSet()
            return ChallengeCalculator.progress(approved, start.plusDays(29), start).percentOfChallenge
        }
        assertEquals(0, pct(0))
        assertEquals(3, pct(1))
        assertEquals(50, pct(15))
        assertEquals(100, pct(30))
    }

    @Test fun onlyApprovedDaysInsideTheWindowCount() {
        val approved = setOf(
            LocalDate.of(2026, 2, 28),   // before start
            LocalDate.of(2026, 3, 1),
            LocalDate.of(2026, 3, 2),
            LocalDate.of(2026, 3, 3)     // future relative to today below
        )
        val p = ChallengeCalculator.progress(approved, LocalDate.of(2026, 3, 2), start)
        assertEquals(2, p.approvedInWindow)
        assertEquals(2, p.dayNumber)
    }

    @Test fun approvalsAfterDay30_doNotInflateThePercentage() {
        val approved = (0 until 40).map { start.plusDays(it.toLong()) }.toSet()
        val p = ChallengeCalculator.progress(approved, start.plusDays(39), start)
        assertEquals(30, p.approvedInWindow)
        assertEquals(100, p.percentOfChallenge)
    }
}
