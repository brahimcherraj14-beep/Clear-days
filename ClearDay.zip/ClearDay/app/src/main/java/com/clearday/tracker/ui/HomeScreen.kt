package com.clearday.tracker.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.clearday.tracker.UiState
import com.clearday.tracker.domain.CHALLENGE_LENGTH_DAYS
import com.clearday.tracker.domain.CalendarLogic
import com.clearday.tracker.domain.DayStatus
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

@Composable
fun HomeScreen(
    state: UiState,
    onApproveToday: () -> Unit,
    onUndoToday: () -> Unit,
    onOpenCalendar: () -> Unit,
    onOpenSettings: () -> Unit
) {
    var showUndo by remember { mutableStateOf(false) }
    val stats = state.stats
    val dateText = remember(state.today) {
        state.today.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL))
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column {
            Text("ClearDay", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text(dateText, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        // Current streak
        SoftCard(Modifier.fillMaxWidth()) {
            Column(
                Modifier.fillMaxWidth().padding(24.dp).semantics(mergeDescendants = true) {
                    contentDescription = "Current streak: ${stats.currentStreak} days"
                },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Current streak", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    "${stats.currentStreak}",
                    fontSize = 72.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary
                )
                Text(if (stats.currentStreak == 1) "day" else "days", style = MaterialTheme.typography.titleMedium)
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Longest streak", stats.longestStreak, Modifier.weight(1f))
            StatCard("Successful days", stats.totalApproved, Modifier.weight(1f))
        }

        // Today
        SoftCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Box(
                        Modifier.size(44.dp).clip(CircleShape).background(
                            if (stats.todayApproved) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                        ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (stats.todayApproved) {
                            Icon(Icons.Filled.Check, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary)
                        }
                    }
                    Column {
                        Text(
                            if (stats.todayApproved) "Today is approved" else "Today isn't approved yet",
                            style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            if (stats.todayApproved) "Nice work showing up for yourself."
                            else "When your day is done, check in honestly.",
                            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                if (stats.todayApproved) {
                    Button(onClick = {}, enabled = false, modifier = Modifier.fillMaxWidth().height(56.dp)) {
                        Text("Approved for today", style = MaterialTheme.typography.titleMedium)
                    }
                    TextButton(onClick = { showUndo = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Approved by mistake? Undo")
                    }
                } else {
                    Button(onClick = onApproveToday, modifier = Modifier.fillMaxWidth().height(60.dp)) {
                        Text("Approve Today", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        ProgressCard(state)

        // Achievements
        SoftCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Achievements", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    stats.achievements.forEach { a ->
                        Column(
                            Modifier.weight(1f).clip(MaterialTheme.shapes.medium)
                                .background(if (a.unlocked) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerHigh)
                                .padding(vertical = 12.dp)
                                .semantics(mergeDescendants = true) {
                                    contentDescription = "${a.days} day milestone, ${if (a.unlocked) "unlocked" else "locked"}"
                                },
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("${a.days}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
                                color = if (a.unlocked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(if (a.unlocked) "✓ days" else "days", style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = onOpenCalendar, modifier = Modifier.weight(1f).height(52.dp)) {
                Icon(Icons.Filled.DateRange, contentDescription = null)
                Spacer(Modifier.size(8.dp))
                Text("Calendar")
            }
            OutlinedButton(onClick = onOpenSettings, modifier = Modifier.weight(1f).height(52.dp)) {
                Icon(Icons.Filled.Settings, contentDescription = null)
                Spacer(Modifier.size(8.dp))
                Text("Settings")
            }
        }

        Text(
            encouragement(stats.currentStreak, stats.totalApproved),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
        )
    }

    if (showUndo) {
        ConfirmDialog(
            title = "Undo today's approval?",
            text = "Today will go back to \"not approved yet\". You can approve it again any time today.",
            confirmLabel = "Undo",
            onConfirm = onUndoToday,
            onDismiss = { showUndo = false }
        )
    }
}

private fun encouragement(streak: Int, total: Int): String = when {
    streak >= 7 -> "A week or more of consistency. That's real momentum."
    streak in 1..6 -> "Every day you check in is a day you're investing in yourself."
    total > 0 -> "A pause doesn't erase your progress. Your history is safe, and today is a fresh start."
    else -> "Welcome. Take it one day at a time, there's no pressure here."
}

@Composable
private fun StatCard(label: String, value: Int, modifier: Modifier = Modifier) {
    SoftCard(modifier) {
        Column(
            Modifier.fillMaxWidth().padding(18.dp).semantics(mergeDescendants = true) {
                contentDescription = "$label: $value"
            },
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("$value", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun ProgressCard(state: UiState) {
    val p = state.stats.progress
    SoftCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("30-day challenge", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(
                if (p.isFinished) "Challenge complete. You can start a new one in Settings."
                else "Day ${p.dayNumber} of $CHALLENGE_LENGTH_DAYS",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            LinearProgressIndicator(
                progress = { p.approvedInWindow / CHALLENGE_LENGTH_DAYS.toFloat() },
                modifier = Modifier.fillMaxWidth().height(10.dp).clip(CircleShape),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.outlineVariant
            )
            Text(
                "${p.approvedInWindow} of $CHALLENGE_LENGTH_DAYS days approved (${p.percentOfChallenge}%)",
                style = MaterialTheme.typography.bodyMedium
            )
            Column(Modifier.clearAndSetSemantics { }, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                p.windowDays.chunked(10).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        row.forEach { day ->
                            val status = CalendarLogic.statusOf(day, state.today, state.approvedDates, state.challengeStart)
                            val color = when (status) {
                                DayStatus.APPROVED -> MaterialTheme.colorScheme.primary
                                DayStatus.MISSED, DayStatus.BEFORE_CHALLENGE -> MaterialTheme.colorScheme.outline
                                DayStatus.PENDING_TODAY -> MaterialTheme.colorScheme.surfaceContainerHighest
                                DayStatus.FUTURE -> MaterialTheme.colorScheme.outlineVariant
                            }
                            Box(
                                Modifier.weight(1f).aspectRatio(1f).clip(CircleShape).background(color).then(
                                    if (day == state.today) Modifier.border(2.dp, MaterialTheme.colorScheme.primary, CircleShape) else Modifier
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}
