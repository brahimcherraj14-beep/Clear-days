package com.clearday.tracker.domain

import java.time.LocalDate

/** Length of one ClearDay challenge, in days. */
const val CHALLENGE_LENGTH_DAYS = 30

/**
 * Streak rules (all based on local calendar dates, never on 24-hour intervals):
 *
 *  - Only approved dates that are on/after the challenge start and not in the future count.
 *  - Current streak: consecutive approved days ending today. If today is not approved yet,
 *    the streak is still alive and is counted back from yesterday (the day isn't over).
 *    If yesterday is also not approved, the current streak is 0.
 *  - Longest streak: the longest run of consecutive approved days in the current challenge.
 *  - Missing a day never deletes any history; it only ends the current run.
 */
object StreakCalculator {

    fun countedDates(
        approved: Set<LocalDate>,
        today: LocalDate,
        challengeStart: LocalDate
    ): Set<LocalDate> =
        approved.filterTo(HashSet()) { !it.isBefore(challengeStart) && !it.isAfter(today) }

    fun totalApproved(approved: Set<LocalDate>, today: LocalDate, challengeStart: LocalDate): Int =
        countedDates(approved, today, challengeStart).size

    fun currentStreak(approved: Set<LocalDate>, today: LocalDate, challengeStart: LocalDate): Int {
        val counted = countedDates(approved, today, challengeStart)
        var cursor = if (today in counted) today else today.minusDays(1)
        var streak = 0
        while (cursor in counted) {
            streak++
            cursor = cursor.minusDays(1)
        }
        return streak
    }

    fun longestStreak(approved: Set<LocalDate>, today: LocalDate, challengeStart: LocalDate): Int {
        val sorted = countedDates(approved, today, challengeStart).sorted()
        var longest = 0
        var run = 0
        var previous: LocalDate? = null
        for (date in sorted) {
            run = if (previous != null && previous.plusDays(1) == date) run + 1 else 1
            if (run > longest) longest = run
            previous = date
        }
        return longest
    }
}
