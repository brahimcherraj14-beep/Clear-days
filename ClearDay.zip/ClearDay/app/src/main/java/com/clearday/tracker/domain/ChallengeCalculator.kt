package com.clearday.tracker.domain

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.roundToInt

data class ChallengeProgress(
    /** Which day of the challenge today is (0 if the start date is in the future, max 30). */
    val dayNumber: Int,
    /** How many of the 30 challenge days are approved (future days never count). */
    val approvedInWindow: Int,
    /** The 30 calendar dates of the challenge, in order. */
    val windowDays: List<LocalDate>
) {
    /** Approved days as a percentage of the whole 30-day challenge. */
    val percentOfChallenge: Int
        get() = (approvedInWindow * 100f / CHALLENGE_LENGTH_DAYS).roundToInt()

    val isFinished: Boolean
        get() = dayNumber >= CHALLENGE_LENGTH_DAYS
}

object ChallengeCalculator {

    fun windowDays(challengeStart: LocalDate): List<LocalDate> =
        (0 until CHALLENGE_LENGTH_DAYS).map { challengeStart.plusDays(it.toLong()) }

    fun progress(
        approved: Set<LocalDate>,
        today: LocalDate,
        challengeStart: LocalDate
    ): ChallengeProgress {
        val elapsed = ChronoUnit.DAYS.between(challengeStart, today).toInt() + 1
        val counted = StreakCalculator.countedDates(approved, today, challengeStart)
        val window = windowDays(challengeStart)
        return ChallengeProgress(
            dayNumber = elapsed.coerceIn(0, CHALLENGE_LENGTH_DAYS),
            approvedInWindow = window.count { it in counted },
            windowDays = window
        )
    }
}
