package com.clearday.tracker.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.clearday.tracker.data.ClearDayRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/** Fires at the reminder time: shows the notification, then schedules tomorrow's. */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val appContext = context.applicationContext
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val settings = ClearDayRepository(appContext).settings.first()
                if (settings.reminderEnabled) {
                    NotificationHelper.showReminder(appContext)
                    ReminderScheduler.schedule(appContext, settings.reminderHour, settings.reminderMinute)
                }
            } finally {
                pending.finish()
            }
        }
    }
}
