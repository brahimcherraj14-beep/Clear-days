package com.clearday.tracker.domain

import java.time.ZonedDateTime

/**
 * The next moment a daily reminder at [hour]:[minute] (local wall-clock time) should fire.
 * Uses the calendar date in the device's current time zone, so daylight-saving changes and
 * time-zone changes are handled by simply recomputing this value.
 */
fun nextReminderTime(now: ZonedDateTime, hour: Int, minute: Int): ZonedDateTime {
    val today = now.toLocalDate().atTime(hour, minute).atZone(now.zone)
    return if (today.isAfter(now)) today
    else now.toLocalDate().plusDays(1).atTime(hour, minute).atZone(now.zone)
}
