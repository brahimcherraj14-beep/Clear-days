package com.clearday.tracker.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException
import java.time.LocalDate

private val Context.clearDayStore: DataStore<Preferences> by preferencesDataStore(name = "clearday_prefs")

data class UserSettings(
    val reminderEnabled: Boolean = true,
    val reminderHour: Int = 21,
    val reminderMinute: Int = 0,
    val challengeStart: LocalDate? = null
)

/**
 * All data lives in this app's private storage (DataStore). Only dates and a few settings
 * are stored. Nothing is sent anywhere.
 */
class ClearDayRepository(context: Context) {
    private val store = context.applicationContext.clearDayStore

    private val prefsFlow: Flow<Preferences> = store.data.catch {
        if (it is IOException) emit(emptyPreferences()) else throw it
    }

    val approvedDates: Flow<Set<LocalDate>> = prefsFlow.map { prefs ->
        (prefs[APPROVED] ?: emptySet()).mapNotNull { parseDate(it) }.toSet()
    }

    val settings: Flow<UserSettings> = prefsFlow.map { prefs ->
        UserSettings(
            reminderEnabled = prefs[REMINDER_ENABLED] ?: true,
            reminderHour = (prefs[REMINDER_HOUR] ?: 21).coerceIn(0, 23),
            reminderMinute = (prefs[REMINDER_MINUTE] ?: 0).coerceIn(0, 59),
            challengeStart = prefs[CHALLENGE_START]?.let { parseDate(it) }
        )
    }

    /** Adding the same date twice is impossible: dates are kept in a set. */
    suspend fun setApproved(date: LocalDate, approved: Boolean) {
        store.edit { prefs ->
            val current = prefs[APPROVED] ?: emptySet()
            prefs[APPROVED] = if (approved) current + date.toString() else current - date.toString()
        }
    }

    suspend fun ensureChallengeStart(today: LocalDate) {
        store.edit { prefs ->
            if (prefs[CHALLENGE_START]?.let { parseDate(it) } == null) {
                prefs[CHALLENGE_START] = today.toString()
            }
        }
    }

    suspend fun setChallengeStart(date: LocalDate) {
        store.edit { it[CHALLENGE_START] = date.toString() }
    }

    suspend fun setReminder(enabled: Boolean, hour: Int, minute: Int) {
        store.edit {
            it[REMINDER_ENABLED] = enabled
            it[REMINDER_HOUR] = hour
            it[REMINDER_MINUTE] = minute
        }
    }

    /** Returns true only the first time it is called (used to ask for notification permission once). */
    suspend fun consumeNotificationPrompt(): Boolean {
        var first = false
        store.edit { prefs ->
            first = prefs[PERMISSION_PROMPTED] != true
            prefs[PERMISSION_PROMPTED] = true
        }
        return first
    }

    /** Deletes all progress. Reminder preferences are kept. */
    suspend fun deleteProgress() {
        store.edit {
            it.remove(APPROVED)
            it.remove(CHALLENGE_START)
        }
    }

    private fun parseDate(raw: String): LocalDate? = runCatching { LocalDate.parse(raw) }.getOrNull()

    private companion object {
        val APPROVED = stringSetPreferencesKey("approved_dates")
        val CHALLENGE_START = stringPreferencesKey("challenge_start")
        val REMINDER_ENABLED = booleanPreferencesKey("reminder_enabled")
        val REMINDER_HOUR = intPreferencesKey("reminder_hour")
        val REMINDER_MINUTE = intPreferencesKey("reminder_minute")
        val PERMISSION_PROMPTED = booleanPreferencesKey("notification_permission_prompted")
    }
}
