package com.clearday.tracker.domain

data class Achievement(val days: Int, val unlocked: Boolean)

object Achievements {
    val MILESTONES = listOf(3, 7, 14, 30)

    /** Milestones are unlocked by the longest consecutive streak of the current challenge. */
    fun evaluate(longestStreak: Int): List<Achievement> =
        MILESTONES.map { Achievement(it, longestStreak >= it) }
}
