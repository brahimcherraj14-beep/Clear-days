package com.clearday.tracker.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val Green = Color(0xFF4ADE80)

private val ClearDayColors = darkColorScheme(
    primary = Green,
    onPrimary = Color(0xFF04210F),
    primaryContainer = Color(0xFF14532D),
    onPrimaryContainer = Color(0xFFD1FAE5),
    secondary = Color(0xFF86EFAC),
    onSecondary = Color(0xFF04210F),
    background = Color(0xFF0D1311),
    onBackground = Color(0xFFE8F0EC),
    surface = Color(0xFF0D1311),
    onSurface = Color(0xFFE8F0EC),
    surfaceVariant = Color(0xFF18221E),
    onSurfaceVariant = Color(0xFFB4C4BC),
    surfaceContainerLowest = Color(0xFF0A0F0D),
    surfaceContainerLow = Color(0xFF131B18),
    surfaceContainer = Color(0xFF18221E),
    surfaceContainerHigh = Color(0xFF1F2B26),
    surfaceContainerHighest = Color(0xFF26352F),
    outline = Color(0xFF7C8F86),
    outlineVariant = Color(0xFF3A4A43),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005)
)

@Composable
fun ClearDayTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ClearDayColors,
        typography = Typography(),
        shapes = Shapes(
            small = RoundedCornerShape(12.dp),
            medium = RoundedCornerShape(20.dp),
            large = RoundedCornerShape(28.dp),
            extraLarge = RoundedCornerShape(28.dp)
        ),
        content = content
    )
}
