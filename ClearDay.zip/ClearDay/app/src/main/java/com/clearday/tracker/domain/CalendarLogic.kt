package com.clearday.tracker.domain

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth

enum class DayStatus {
    /** Approved day. */
    APPROVED,
    /** Past day inside the challenge that was not approved. */
    MISSED,
    /** Today, not yet approved. */
    PENDING_TODAY,
    /** A day that hasn't happened yet. Never counts. */
    FUTURE,
    /** A not-approved day before the current challenge started. */
    BEFORE_CHALLENGE
}

object CalendarLogic {

    fun statusOf(
        date: LocalDate,
        today: LocalDate,
        approved: Set<LocalDate>,
        challengeStart: LocalDate
    ): DayStatus = when {
        date.isAfter(today) -> DayStatus.FUTURE
        date in approved -> DayStatus.APPROVED
        date.isBefore(challengeStart) -> DayStatus.BEFORE_CHALLENGE
        date == today -> DayStatus.PENDING_TODAY
        else -> DayStatus.MISSED
    }

    /** A day can be changed only if it is not in the future and not before the challenge start. */
    fun canEdit(date: LocalDate, today: LocalDate, challengeStart: LocalDate): Boolean =
        !date.isAfter(today) && !date.isBefore(challengeStart)

    /**
     * The cells of a month grid: leading nulls for the empty cells before the 1st,
     * then every date of the month, then trailing nulls so the size is a multiple of 7.
     */
    fun monthGrid(month: YearMonth, firstDayOfWeek: DayOfWeek): List<LocalDate?> {
        val leading = (month.atDay(1).dayOfWeek.value - firstDayOfWeek.value + 7) % 7
        val cells = ArrayList<LocalDate?>()
        repeat(leading) { cells.add(null) }
        for (day in 1..month.lengthOfMonth()) cells.add(month.atDay(day))
        while (cells.size % 7 != 0) cells.add(null)
        return cells
    }
}
