package com.clearday.tracker.ui

import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.clearday.tracker.MainViewModel

private const val HOME = "home"
private const val CALENDAR = "calendar"
private const val SETTINGS = "settings"

@Composable
fun ClearDayRoot(
    viewModel: MainViewModel,
    onRequestNotificationPermission: () -> Unit,
    onExport: () -> Unit
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    var screen by rememberSaveable { mutableStateOf(HOME) }
    val context = LocalContext.current

    var notificationsAllowed by remember {
        mutableStateOf(NotificationManagerCompat.from(context).areNotificationsEnabled())
    }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        notificationsAllowed = NotificationManagerCompat.from(context).areNotificationsEnabled()
    }

    BackHandler(enabled = screen != HOME) { screen = HOME }

    LaunchedEffect(Unit) {
        viewModel.messages.collect { snackbarHostState.showSnackbar(it) }
    }

    // Ask for notification permission once, on Android 13+.
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && !notificationsAllowed && viewModel.consumeNotificationPrompt()) {
            onRequestNotificationPermission()
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(Modifier.fillMaxSize().padding(innerPadding)) {
            AnimatedContent(
                targetState = screen,
                transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(160)) },
                label = "screen"
            ) { target ->
                when (target) {
                    CALENDAR -> CalendarScreen(
                        state = state,
                        onBack = { screen = HOME },
                        onSetDayApproved = viewModel::setDayApproved
                    )
                    SETTINGS -> SettingsScreen(
                        state = state,
                        notificationsAllowed = notificationsAllowed,
                        onBack = { screen = HOME },
                        onRequestNotificationPermission = onRequestNotificationPermission,
                        onReminderEnabled = viewModel::setReminderEnabled,
                        onReminderTime = viewModel::setReminderTime,
                        onChallengeStart = viewModel::setChallengeStart,
                        onNewChallenge = viewModel::startNewChallenge,
                        onExport = onExport,
                        onDeleteAll = viewModel::deleteAllData
                    )
                    else -> HomeScreen(
                        state = state,
                        onApproveToday = viewModel::approveToday,
                        onUndoToday = viewModel::unapproveToday,
                        onOpenCalendar = { screen = CALENDAR },
                        onOpenSettings = { screen = SETTINGS }
                    )
                }
            }
        }
    }
}
