package com.clearday.tracker.ui

import android.os.Build
import android.text.format.DateFormat
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SelectableDates
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.clearday.tracker.UiState
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    state: UiState,
    notificationsAllowed: Boolean,
    onBack: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onReminderEnabled: (Boolean) -> Unit,
    onReminderTime: (Int, Int) -> Unit,
    onChallengeStart: (LocalDate) -> Unit,
    onNewChallenge: () -> Unit,
    onExport: () -> Unit,
    onDeleteAll: () -> Unit
) {
    val context = LocalContext.current
    var showTimePicker by remember { mutableStateOf(false) }
    var showDatePicker by remember { mutableStateOf(false) }
    var showNewChallenge by remember { mutableStateOf(false) }
    var showDelete by remember { mutableStateOf(false) }

    val timeText = LocalTime.of(state.reminderHour, state.reminderMinute)
        .format(DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT))
    val startText = state.challengeStart.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM))

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader("Settings", onBack)

        Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {

            SoftCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SectionTitle("Daily reminder")
                    Row(
                        Modifier.fillMaxWidth().toggleable(
                            value = state.reminderEnabled, role = Role.Switch, onValueChange = onReminderEnabled
                        ),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Remind me every day", Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                        Switch(checked = state.reminderEnabled, onCheckedChange = null)
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Reminder time: $timeText", Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                        OutlinedButton(onClick = { showTimePicker = true }, enabled = state.reminderEnabled) {
                            Text("Change")
                        }
                    }
                    if (state.reminderEnabled && !notificationsAllowed) {
                        Text(
                            "Notifications are turned off for ClearDay, so reminders can't appear.",
                            color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium
                        )
                        Button(onClick = {
                            if (Build.VERSION.SDK_INT >= 33) onRequestNotificationPermission()
                            // If Android won't show the prompt again, the user can enable it in
                            // Settings > Apps > ClearDay > Notifications.
                        }) { Text("Allow notifications") }
                        Text(
                            "If no prompt appears, open Android Settings > Apps > ClearDay > Notifications and turn them on.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        "Reminders use Android's battery-friendly scheduling, so they can arrive a few minutes late, " +
                            "especially with Battery Saver on or if the phone has been idle for a long time. " +
                            "They're rescheduled automatically after a restart or time-zone change.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            SoftCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SectionTitle("Challenge")
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Start date: $startText", Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                        OutlinedButton(onClick = { showDatePicker = true }) { Text("Change") }
                    }
                    OutlinedButton(onClick = { showNewChallenge = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Start a new challenge")
                    }
                    Text(
                        "Starting a new challenge begins a fresh 30 days from today. Your earlier approved days stay saved in the calendar.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            SoftCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SectionTitle("Your data")
                    Text(
                        "Everything stays on this phone. ClearDay has no account, no internet access, no analytics and no ads.",
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedButton(onClick = onExport, modifier = Modifier.fillMaxWidth()) { Text("Export my data") }
                    OutlinedButton(
                        onClick = { showDelete = true }, modifier = Modifier.fillMaxWidth()
                    ) { Text("Delete all my data", color = MaterialTheme.colorScheme.error) }
                }
            }
        }
    }

    if (showTimePicker) {
        ReminderTimeDialog(
            initialHour = state.reminderHour,
            initialMinute = state.reminderMinute,
            is24Hour = DateFormat.is24HourFormat(context),
            onDismiss = { showTimePicker = false },
            onConfirm = { h, m -> onReminderTime(h, m); showTimePicker = false }
        )
    }

    if (showDatePicker) {
        val today = state.today
        val pickerState = rememberDatePickerState(
            initialSelectedDateMillis = state.challengeStart.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli(),
            selectableDates = object : SelectableDates {
                override fun isSelectableDate(utcTimeMillis: Long): Boolean =
                    !Instant.ofEpochMilli(utcTimeMillis).atZone(ZoneOffset.UTC).toLocalDate().isAfter(today)
            }
        )
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    pickerState.selectedDateMillis?.let {
                        onChallengeStart(Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate())
                    }
                    showDatePicker = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showDatePicker = false }) { Text("Cancel") } }
        ) { DatePicker(state = pickerState) }
    }

    if (showNewChallenge) {
        ConfirmDialog(
            title = "Start a new challenge?",
            text = "A new 30-day challenge will begin today. Your previous approved days are kept in the calendar.",
            confirmLabel = "Start new challenge",
            onConfirm = onNewChallenge,
            onDismiss = { showNewChallenge = false }
        )
    }

    if (showDelete) {
        ConfirmDialog(
            title = "Delete all your data?",
            text = "This permanently deletes every approved day and your challenge start date. It can't be undone. You may want to export your data first.",
            confirmLabel = "Delete permanently",
            onConfirm = onDeleteAll,
            onDismiss = { showDelete = false }
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ReminderTimeDialog(
    initialHour: Int,
    initialMinute: Int,
    is24Hour: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (Int, Int) -> Unit
) {
    val pickerState = rememberTimePickerState(initialHour, initialMinute, is24Hour)
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            shape = MaterialTheme.shapes.extraLarge,
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            tonalElevation = 6.dp,
            modifier = Modifier.width(IntrinsicSize.Min)
        ) {
            Column(Modifier.padding(24.dp)) {
                Text("Reminder time", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(bottom = 20.dp))
                TimePicker(state = pickerState)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    TextButton(onClick = { onConfirm(pickerState.hour, pickerState.minute) }) { Text("Save") }
                }
            }
        }
    }
}
