package com.clearday.tracker.domain

import java.time.LocalDate

data class DashboardStats(
    val currentStreak: Int,
    val longestStreak: Int,
    val totalApproved: Int,
    val todayApproved: Boolean,
    val progress: ChallengeProgress,
    val achievements: List<Achievement>
)

object DashboardCalculator {
    fun compute(
        approved: Set<LocalDate>,
        today: LocalDate,
        challengeStart: LocalDate
    ): DashboardStats {
        val longest = StreakCalculator.longestStreak(approved, today, challengeStart)
        return DashboardStats(
            currentStreak = StreakCalculator.currentStreak(approved, today, challengeStart),
            longestStreak = longest,
            totalApproved = StreakCalculator.totalApproved(approved, today, challengeStart),
            todayApproved = today in approved && !today.isBefore(challengeStart),
            progress = ChallengeCalculator.progress(approved, today, challengeStart),
            achievements = Achievements.evaluate(longest)
        )
    }
}
