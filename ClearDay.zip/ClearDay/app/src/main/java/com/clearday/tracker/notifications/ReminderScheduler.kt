package com.clearday.tracker.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.clearday.tracker.data.ClearDayRepository
import com.clearday.tracker.domain.nextReminderTime
import kotlinx.coroutines.flow.first
import java.time.ZonedDateTime

/**
 * Schedules ONE inexact alarm for the next reminder; the receiver schedules the following one.
 * This needs no special "exact alarm" permission. Android may delay inexact alarms a little
 * (battery saver, Doze, app standby), so a reminder can arrive a few minutes late.
 */
object ReminderScheduler {
    private const val REQUEST_CODE = 4021

    private fun pendingIntent(context: Context): PendingIntent = PendingIntent.getBroadcast(
        context,
        REQUEST_CODE,
        Intent(context, ReminderReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun schedule(context: Context, hour: Int, minute: Int) {
        val alarmManager = context.getSystemService(AlarmManager::class.java)
        val trigger = nextReminderTime(ZonedDateTime.now(), hour, minute)
        alarmManager.setAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            trigger.toInstant().toEpochMilli(),
            pendingIntent(context)
        )
    }

    fun cancel(context: Context) {
        context.getSystemService(AlarmManager::class.java).cancel(pendingIntent(context))
    }

    suspend fun rescheduleFromSettings(context: Context) {
        val settings = ClearDayRepository(context).settings.first()
        if (settings.reminderEnabled) {
            schedule(context, settings.reminderHour, settings.reminderMinute)
        } else {
            cancel(context)
        }
    }
}
