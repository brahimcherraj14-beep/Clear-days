package com.clearday.tracker

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.clearday.tracker.data.ClearDayRepository
import com.clearday.tracker.domain.CalendarLogic
import com.clearday.tracker.domain.DashboardCalculator
import com.clearday.tracker.domain.DashboardStats
import com.clearday.tracker.domain.ExportFormatter
import com.clearday.tracker.notifications.ReminderScheduler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime

private fun stats(approved: Set<LocalDate>, today: LocalDate, start: LocalDate) =
    DashboardCalculator.compute(approved, today, start)

data class UiState(
    val isLoading: Boolean = true,
    val today: LocalDate = LocalDate.now(),
    val approvedDates: Set<LocalDate> = emptySet(),
    val challengeStart: LocalDate = LocalDate.now(),
    val reminderEnabled: Boolean = true,
    val reminderHour: Int = 21,
    val reminderMinute: Int = 0,
    val stats: DashboardStats = stats(emptySet(), LocalDate.now(), LocalDate.now())
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = ClearDayRepository(application)
    private val todayFlow = MutableStateFlow(LocalDate.now())
    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 4)

    /** One-off messages for the snackbar. */
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    val uiState: StateFlow<UiState> = combine(
        repository.approvedDates, repository.settings, todayFlow
    ) { approved, settings, today ->
        val start = settings.challengeStart ?: today
        UiState(
            isLoading = false,
            today = today,
            approvedDates = approved,
            challengeStart = start,
            reminderEnabled = settings.reminderEnabled,
            reminderHour = settings.reminderHour,
            reminderMinute = settings.reminderMinute,
            stats = stats(approved, today, start)
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, UiState())

    init {
        viewModelScope.launch {
            repository.ensureChallengeStart(LocalDate.now())
            ReminderScheduler.rescheduleFromSettings(getApplication())
        }
        // Refresh "today" when midnight passes while the app is open.
        viewModelScope.launch {
            while (true) {
                val now = LocalDateTime.now()
                val nextMidnight = now.toLocalDate().plusDays(1).atStartOfDay()
                delay(Duration.between(now, nextMidnight).toMillis() + 500)
                todayFlow.value = LocalDate.now()
            }
        }
    }

    fun refreshToday() {
        todayFlow.value = LocalDate.now()
    }

    /** Only ever approves today's local date, and only when the user presses the button. */
    fun approveToday() {
        viewModelScope.launch {
            val today = LocalDate.now()
            todayFlow.value = today
            repository.setApproved(today, true)
        }
    }

    fun unapproveToday() {
        viewModelScope.launch { repository.setApproved(LocalDate.now(), false) }
    }

    /** Used by the calendar. Future days and days before the challenge start are refused. */
    fun setDayApproved(date: LocalDate, approved: Boolean) {
        viewModelScope.launch {
            val today = LocalDate.now()
            val start = uiState.value.challengeStart
            if (CalendarLogic.canEdit(date, today, start)) {
                repository.setApproved(date, approved)
            }
        }
    }

    fun setReminderEnabled(enabled: Boolean) {
        val s = uiState.value
        applyReminder(enabled, s.reminderHour, s.reminderMinute)
    }

    fun setReminderTime(hour: Int, minute: Int) {
        applyReminder(uiState.value.reminderEnabled, hour, minute)
    }

    private fun applyReminder(enabled: Boolean, hour: Int, minute: Int) {
        viewModelScope.launch {
            repository.setReminder(enabled, hour, minute)
            if (enabled) ReminderScheduler.schedule(getApplication(), hour, minute)
            else ReminderScheduler.cancel(getApplication())
        }
    }

    fun setChallengeStart(date: LocalDate) {
        if (date.isAfter(LocalDate.now())) return
        viewModelScope.launch { repository.setChallengeStart(date) }
    }

    /** Starts a new 30-day challenge today. Earlier approved days stay in the calendar. */
    fun startNewChallenge() {
        viewModelScope.launch {
            repository.setChallengeStart(LocalDate.now())
            _messages.emit("New challenge started. Your earlier history is kept.")
        }
    }

    fun deleteAllData() {
        viewModelScope.launch {
            repository.deleteProgress()
            repository.ensureChallengeStart(LocalDate.now())
            _messages.emit("All progress deleted.")
        }
    }

    fun exportTo(uri: Uri) {
        viewModelScope.launch {
            val state = uiState.value
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val json = ExportFormatter.toJson(LocalDate.now(), state.challengeStart, state.approvedDates)
                    val stream = getApplication<Application>().contentResolver.openOutputStream(uri, "wt")
                        ?: throw IOException("Could not open file")
                    stream.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                }
            }
            _messages.emit(
                if (result.isSuccess) "Export saved." else "Couldn't save the file. Please try again."
            )
        }
    }

    suspend fun consumeNotificationPrompt(): Boolean = repository.consumeNotificationPrompt()
}
