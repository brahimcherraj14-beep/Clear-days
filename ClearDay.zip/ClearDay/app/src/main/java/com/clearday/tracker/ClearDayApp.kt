package com.clearday.tracker

import android.app.Application
import com.clearday.tracker.notifications.NotificationHelper

class ClearDayApp : Application() {
    override fun onCreate() {
        super.onCreate()
        NotificationHelper.createChannel(this)
    }
}
