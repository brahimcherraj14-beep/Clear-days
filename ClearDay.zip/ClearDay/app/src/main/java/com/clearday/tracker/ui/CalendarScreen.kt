package com.clearday.tracker.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.clearday.tracker.UiState
import com.clearday.tracker.domain.CalendarLogic
import com.clearday.tracker.domain.DayStatus
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.time.format.TextStyle
import java.time.temporal.WeekFields
import java.util.Locale

@Composable
fun CalendarScreen(
    state: UiState,
    onBack: () -> Unit,
    onSetDayApproved: (LocalDate, Boolean) -> Unit
) {
    var monthOffset by rememberSaveable { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<LocalDate?>(null) }

    val locale = Locale.getDefault()
    val firstDow = remember(locale) { WeekFields.of(locale).firstDayOfWeek }
    val month = YearMonth.from(state.today).plusMonths(monthOffset.toLong())
    val cells = remember(month, firstDow) { CalendarLogic.monthGrid(month, firstDow) }
    val monthTitle = month.format(DateTimeFormatter.ofPattern("LLLL yyyy", locale))

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader("Calendar", onBack)

        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { monthOffset -= 1 }) {
                    Icon(Icons.Filled.KeyboardArrowLeft, contentDescription = "Previous month")
                }
                Text(
                    monthTitle,
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold
                )
                IconButton(onClick = { monthOffset += 1 }) {
                    Icon(Icons.Filled.KeyboardArrowRight, contentDescription = "Next month")
                }
            }

            Row(Modifier.fillMaxWidth().clearAndSetSemantics { }) {
                for (i in 0 until 7) {
                    Text(
                        firstDow.plus(i.toLong()).getDisplayName(TextStyle.NARROW, locale),
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            cells.chunked(7).forEach { week ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    week.forEach { date ->
                        if (date == null) {
                            Box(Modifier.weight(1f).aspectRatio(1f))
                        } else {
                            DayCell(
                                date = date,
                                state = state,
                                modifier = Modifier.weight(1f),
                                onClick = { selected = date }
                            )
                        }
                    }
                }
            }

            Legend()
        }
    }

    selected?.let { date ->
        val status = CalendarLogic.statusOf(date, state.today, state.approvedDates, state.challengeStart)
        val editable = CalendarLogic.canEdit(date, state.today, state.challengeStart)
        val startText = state.challengeStart.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM))
        val body = when (status) {
            DayStatus.APPROVED -> "This day is approved."
            DayStatus.MISSED -> "Not approved. That's okay: every new day is a fresh chance."
            DayStatus.PENDING_TODAY -> "Today isn't approved yet."
            DayStatus.FUTURE -> "This day hasn't happened yet. Future days never count."
            DayStatus.BEFORE_CHALLENGE -> "This is before your current challenge start ($startText). Your older history is kept."
        }
        val approvedNow = status == DayStatus.APPROVED
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text(date.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL))) },
            text = {
                Text(
                    if (editable && approvedNow) "$body Do you want to remove the approval for this day?"
                    else if (editable) "$body Only mark it as approved if it's true."
                    else body
                )
            },
            confirmButton = {
                if (editable) {
                    TextButton(onClick = {
                        onSetDayApproved(date, !approvedNow)
                        selected = null
                    }) { Text(if (approvedNow) "Remove approval" else "Mark as approved") }
                }
            },
            dismissButton = { TextButton(onClick = { selected = null }) { Text("Close") } }
        )
    }
}

@Composable
private fun DayCell(date: LocalDate, state: UiState, modifier: Modifier, onClick: () -> Unit) {
    val status = CalendarLogic.statusOf(date, state.today, state.approvedDates, state.challengeStart)
    val scheme = MaterialTheme.colorScheme
    val background = when (status) {
        DayStatus.APPROVED -> scheme.primary
        DayStatus.MISSED, DayStatus.PENDING_TODAY -> scheme.surfaceContainerHighest
        DayStatus.BEFORE_CHALLENGE, DayStatus.FUTURE -> Color.Transparent
    }
    val textColor = when (status) {
        DayStatus.APPROVED -> scheme.onPrimary
        DayStatus.MISSED, DayStatus.PENDING_TODAY -> scheme.onSurface
        DayStatus.BEFORE_CHALLENGE, DayStatus.FUTURE -> scheme.onSurfaceVariant.copy(alpha = 0.6f)
    }
    val isToday = date == state.today
    val label = date.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL)) + ", " + when (status) {
        DayStatus.APPROVED -> "approved"
        DayStatus.MISSED -> "not approved"
        DayStatus.PENDING_TODAY -> "today, not approved yet"
        DayStatus.FUTURE -> "future day"
        DayStatus.BEFORE_CHALLENGE -> "before challenge start"
    } + if (isToday && status == DayStatus.APPROVED) ", today" else ""

    Box(
        modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(14.dp))
            .background(background)
            .then(if (isToday) Modifier.border(2.dp, scheme.primary, RoundedCornerShape(14.dp)) else Modifier)
            .clickable(onClick = onClick)
            .semantics(mergeDescendants = true) { contentDescription = label },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("${date.dayOfMonth}", color = textColor, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
            if (status == DayStatus.APPROVED) {
                Text("✓", color = textColor, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun Legend() {
    val scheme = MaterialTheme.colorScheme
    Column(Modifier.padding(top = 8.dp, bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        LegendItem(scheme.primary, null, "Approved day")
        LegendItem(scheme.surfaceContainerHighest, null, "Not approved (past day)")
        LegendItem(Color.Transparent, scheme.primary, "Today")
        LegendItem(Color.Transparent, scheme.outlineVariant, "Future day or before your challenge")
    }
}

@Composable
private fun LegendItem(fill: Color, border: Color?, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(
            Modifier.size(20.dp).clip(CircleShape).background(fill)
                .then(if (border != null) Modifier.border(2.dp, border, CircleShape) else Modifier)
        )
        Text(text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
