package com.clearday.tracker.domain

import java.time.LocalDate

/** Builds the human-readable JSON text for "Export my data". Contains only dates. */
object ExportFormatter {
    fun toJson(exportedOn: LocalDate, challengeStart: LocalDate, approved: Set<LocalDate>): String {
        val dates = approved.sorted().joinToString(",\n") { "    \"$it\"" }
        return buildString {
            append("{\n")
            append("  \"app\": \"ClearDay\",\n")
            append("  \"exportedOn\": \"$exportedOn\",\n")
            append("  \"currentChallengeStart\": \"$challengeStart\",\n")
            append("  \"approvedDates\": [")
            if (dates.isNotEmpty()) append("\n").append(dates).append("\n  ")
            append("]\n")
            append("}\n")
        }
    }
}
